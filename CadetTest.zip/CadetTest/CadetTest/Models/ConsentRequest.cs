﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CadetTest.Models
{
    public class ConsentRequest
    {
        public int StartId { get; set; }
        public int Count { get; set; }
    }
}
